import React from 'react'

export default function ShopingCartIcon() {
  return (
    <div>ShopingCartIcon</div>
  )
}
